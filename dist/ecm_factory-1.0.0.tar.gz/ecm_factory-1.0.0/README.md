# time_series_regression_factory

Set of functions allowing the efficient development of linear regression models.

## Installation

You can install the package using pip:

```bash
pip install time_series_regression_factory